# Contributing to the toolkit

We welcome patches to the toolkit. Please submit any changes
to [the toolkit repository][govuk_frontend_toolkit] and they'll
be included in the npm package when a new version is released.

You shouldn't need to make any changes this repository to change
the toolkit.

[govuk_frontend_toolkit]: https://www.npmjs.org/package/govuk_frontend_toolkit
